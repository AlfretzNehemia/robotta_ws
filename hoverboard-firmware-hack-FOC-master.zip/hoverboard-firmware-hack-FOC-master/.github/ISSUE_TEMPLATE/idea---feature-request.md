---
name: Idea / Feature request
about: Suggest an idea for this project
title: ''
labels: enhancement
assignees: ''

---

**What can we do to make the firmware better?**
Consider if code examples or images would help communicate your request.

**Describe suggestions or alternatives you have considered**
A clear and concise description of any alternative solutions or features you've considered.
