---
name: Bug report
about: Create a report to help us improve
title: ''
labels: bug
assignees: ''

---

### Your System
- VARIANT:
- CONTROL TYPE:
- CONTROL MODE:
- What is your application?
    - Hovercar, Skateboard, RC platform, etc.

Describe the bug and how we can reproduce it.

```c
// a code sample may improve communication
```
